import pandas as pd
from crud import *
from analise import *
import os

# Caminho para o dataset tratado
FICHEIRO = r'C:\Users\Asus\Desktop\Backup\Projeto Artigos Cientificos\data\Producao_cientifica_tratado.csv'
df = pd.read_csv(FICHEIRO)

# Função para exibir o menu principal
def menu():
    print("\n📚 **Sistema de Gestão de Publicações Científicas** 📚")
    print("1. Criar Publicação")
    print("2. Consultar Publicação por ID")
    print("3. Atualizar Publicação")
    print("4. Eliminar Publicação")
    print("5. Listar Publicações")
    print("6. Ordenar Publicações")
    print("7. Importar Dados de Outro Ficheiro")
    print("8. Exportar Dados Filtrados")
    print("9. Guardar Alterações")
    print("10. Análises Estatísticas")
    print("11. Sair")

# Submenu para análises estatísticas
def menu_analises():
    print("\n📊 **Análises Estatísticas** 📊")
    print("1. Distribuição de Publicações por Ano")
    print("2. Distribuição de Publicações por Mês em um Ano Específico")
    print("3. Top 20 Autores Mais Produtivos")
    print("4. Distribuição de Publicações de um Autor por Ano")
    print("5. Top 20 Palavras-chave Mais Frequentes")
    print("6. Distribuição de Palavras-chave por Ano")
    print("7. Voltar ao Menu Principal")

def main():
    global df
    while True:
        menu()
        escolha = input("Escolha uma opção: ")

        if escolha == '1':
            nova_publicacao = {
                'Key': input("ID: "),
                'Item Type': input("Tipo: "),
                'Publication Year': int(input("Ano: ")),
                'Author': input("Autor: "),
                'Title': input("Título: "),
                'Publication Title': input("Revista: "),
                'DOI': input("DOI: "),
                'Url': input("URL: "),
                'Abstract Note': input("Resumo: "),
                'Manual Tags': input("Etiquetas: "),
                'Date': input("Data (DD-MM-AAAA): ")
            }
            df = criar_publicacao(df, nova_publicacao)

        elif escolha == '2':
            key = input("ID da Publicação: ")
            resultado = consultar_publicacao(df, key)
            if resultado:
                print(resultado)

        elif escolha == '3':
            key = input("ID da Publicação: ")
            campo = input("Campo a atualizar: ")
            valor = input("Novo valor: ")
            df = atualizar_publicacao(df, key, {campo: valor})

        elif escolha == '4':
            key = input("ID da Publicação: ")
            df = eliminar_publicacao(df, key)

        elif escolha == '5':
            filtro = input("Filtro (ex: Author=Nome): ").split('=')
            if len(filtro) == 2:
                resultados = consultar_publicacoes(df, {filtro[0]: filtro[1]})
                print(resultados.head())
            else:
                print(df.head())

        elif escolha == '6':
            coluna = input("Ordenar por (Title/Publication Year): ")
            asc = input("Ascendente? (s/n): ").lower() == 's'
            df = ordenar_publicacoes(df, coluna, asc)
            print(df.head())

        elif escolha == '7':
            nome_ficheiro = input("Nome do ficheiro CSV para importar (ex: novos_dados.csv): ")
            caminho_ficheiro = os.path.join('./data', nome_ficheiro)
            if os.path.exists(caminho_ficheiro):
                df = importar_dados(df, caminho_ficheiro)
            else:
                print(f"⚠️ O ficheiro '{nome_ficheiro}' não foi encontrado na pasta 'data'.")

        elif escolha == '8':
            filtro = input("Filtro para exportação (ex: Author=Nome): ").split('=')
            if len(filtro) == 2:
                ficheiro_saida = input("Nome do ficheiro de saída (ex: dados_filtrados.csv): ")
                caminho_saida = os.path.join('./data', ficheiro_saida)
                exportar_dados_filtrados(df, {filtro[0]: filtro[1]}, caminho_saida)

        elif escolha == '9':
            guardar_alteracoes(df)
            print("✅ Alterações guardadas!")

        elif escolha == '10':
            while True:
                menu_analises()
                escolha_analise = input("Escolha uma análise: ")
                if escolha_analise == '1':
                    distribuicao_publicacoes_por_ano(df)
                elif escolha_analise == '2':
                    ano = int(input("Insira o ano para análise mensal: "))
                    distribuicao_publicacoes_por_mes(df, ano)
                elif escolha_analise == '3':
                    top_autores_mais_produtivos(df)
                elif escolha_analise == '4':
                    autor = input("Insira o nome do autor: ")
                    distribuicao_publicacoes_por_autor(df, autor)
                elif escolha_analise == '5':
                    top_palavras_chave(df)
                elif escolha_analise == '6':
                    distribuicao_palavras_chave_por_ano(df)
                elif escolha_analise == '7':
                    break
                else:
                    print("⚠️ Opção inválida, tente novamente.")

        elif escolha == '11':
            print("👋 Adeus!")
            break

if __name__ == '__main__':
    main()
