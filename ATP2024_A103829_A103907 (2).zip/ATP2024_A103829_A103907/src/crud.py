import pandas as pd
from datetime import datetime

# Carregar o dataset tratado
FICHEIRO_ORIGINAL = r'C:\Users\Asus\Desktop\Backup\Projeto Artigos Cientificos\data\Producao_cientifica_tratado.csv'
df = pd.read_csv(FICHEIRO_ORIGINAL)

# Garantir que a coluna Date está corretamente formatada
df['Date'] = pd.to_datetime(df['Date'], format='%d-%m-%Y', errors='coerce')

# 1. CRIAR PUBLICAÇÃO
def criar_publicacao(df, nova_publicacao):
    """
    Adiciona uma nova publicação ao DataFrame.
    nova_publicacao: dicionário com as colunas do dataset.
    """
    if 'Date' in nova_publicacao:
        try:
            nova_publicacao['Date'] = datetime.strptime(nova_publicacao['Date'], '%d-%m-%Y').strftime('%d-%m-%Y')
        except (ValueError, TypeError):
            print("⚠️ Formato de data inválido! Use dd-mm-aaaa.")
            nova_publicacao['Date'] = None
    
    df = pd.concat([df, pd.DataFrame([nova_publicacao])], ignore_index=True)
    print("✅ Publicação criada com sucesso!")
    return df

# 2. ATUALIZAR PUBLICAÇÃO
def atualizar_publicacao(df, key, novos_dados):
    """
    Atualiza informações de uma publicação com base na 'Key'.
    novos_dados: dicionário com dados atualizados.
    """
    if key in df['Key'].values:
        for coluna, valor in novos_dados.items():
            if coluna == 'Date':
                try:
                    valor = datetime.strptime(valor, '%d-%m-%Y').strftime('%d-%m-%Y')
                except (ValueError, TypeError):
                    print("⚠️ Formato de data inválido! Use dd-mm-aaaa.")
                    valor = None
            df.loc[df['Key'] == key, coluna] = valor
        print("✅ Publicação atualizada com sucesso!")
    else:
        print("⚠️ Publicação não encontrada!")
    return df

# 3. ELIMINAR PUBLICAÇÃO
def eliminar_publicacao(df, key):
    """
    Remove uma publicação com base na 'Key'.
    """
    if key in df['Key'].values:
        df = df[df['Key'] != key]
        print("✅ Publicação removida com sucesso!")
    else:
        print("⚠️ Publicação não encontrada!")
    return df

# 4. CONSULTAR PUBLICAÇÃO POR ID
def consultar_publicacao(df, key):
    """
    Retorna informações detalhadas de uma publicação específica.
    """
    resultado = df[df['Key'] == key]
    if not resultado.empty:
        return resultado.iloc[0].to_dict()
    else:
        print("⚠️ Publicação não encontrada!")
        return None

# 5. CONSULTAR PUBLICAÇÕES COM FILTROS
def consultar_publicacoes(df, filtro=None):
    """
    Lista publicações com filtros opcionais.
    filtro: dicionário com colunas como chave e valores desejados.
    """
    if filtro:
        for coluna, valor in filtro.items():
            df = df[df[coluna].str.contains(valor, case=False, na=False)]
    return df

# 6. ORDENAR PUBLICAÇÕES
def ordenar_publicacoes(df, coluna='Title', ascendente=True):
    """
    Ordena publicações por uma coluna específica.
    """
    if coluna in df.columns:
        return df.sort_values(by=coluna, ascending=ascendente)
    else:
        print("⚠️ Coluna inválida para ordenação!")
        return df

# 7. GUARDAR ALTERAÇÕES NO CSV
def guardar_alteracoes(df, ficheiro=FICHEIRO_ORIGINAL):
    """
    Guarda alterações no ficheiro CSV original.
    """
    df.to_csv(ficheiro, index=False)
    print("✅ Alterações guardadas com sucesso!")

# 8. IMPORTAR NOVOS DADOS
def importar_dados(df, ficheiro_novo):
    """
    Importa novos dados de um ficheiro CSV.
    """
    df_novo = pd.read_csv(ficheiro_novo)
    df_novo['Date'] = pd.to_datetime(df_novo['Date'], format='%d-%m-%Y', errors='coerce')
    df = pd.concat([df, df_novo], ignore_index=True)
    print("✅ Dados importados com sucesso!")
    return df

# 9. EXPORTAR DADOS FILTRADOS
def exportar_dados_filtrados(df, filtro, ficheiro_saida):
    """
    Exporta um subconjunto de dados filtrados.
    """
    df_filtrado = consultar_publicacoes(df, filtro)
    df_filtrado.to_csv(ficheiro_saida, index=False)
    print(f"✅ Dados filtrados exportados para {ficheiro_saida}!")
