import PySimpleGUI as sg
import pandas as pd
from crud import *
from analise import *

# Caminho para o dataset tratado
FICHEIRO = r'C:\Users\Asus\Desktop\Backup\Projeto Artigos Cientificos\data\Producao_cientifica_tratado.csv'
df = pd.read_csv(FICHEIRO, low_memory=False)

# Função para atualizar o DataFrame global
def atualizar_dataframe():
    global df
    df = pd.read_csv(FICHEIRO, low_memory=False)

# Função para mostrar resultados na interface
def mostrar_resultado(resultado):
    if resultado:
        sg.popup_scrolled("Resultado", str(resultado))
    else:
        sg.popup("Resultado", "Nenhum resultado encontrado.")

# Layout do separador Importar/Exportar
importar_exportar_layout = [
    [sg.Button('Carregar Dataset', key='CARREGAR_DATASET')],
    [sg.Button('Guardar Alterações', key='GUARDAR_ALTERACOES')],
    [sg.Button('Sair', key='SAIR')]
]

# Layout do separador CRUD
crud_layout = [
    [sg.Text('ID:'), sg.Input(key='ID', size=(30, 1))],
    [sg.Text('Tipo:'), sg.Input(key='Tipo', size=(30, 1))],
    [sg.Text('Ano:'), sg.Input(key='Ano', size=(30, 1))],
    [sg.Text('Autor:'), sg.Input(key='Autor', size=(30, 1))],
    [sg.Text('Título:'), sg.Input(key='Titulo', size=(30, 1))],
    [sg.Text('Título da Publicação:'), sg.Input(key='TituloPublicacao', size=(30, 1))],
    [sg.Text('DOI:'), sg.Input(key='DOI', size=(30, 1))],
    [sg.Text('URL:'), sg.Input(key='URL', size=(30, 1))],
    [sg.Text('Resumo:'), sg.Input(key='Resumo', size=(30, 1))],
    [sg.Text('Etiquetas:'), sg.Input(key='Etiquetas', size=(30, 1))],
    [sg.Text('Data (dd-mm-aaaa):'), sg.Input(key='Data', size=(30, 1))],
    [sg.Text('Campo para Atualização:'), sg.Input(key='CampoAtualizacao', size=(30, 1))],
    [sg.Text('Valor para Atualização:'), sg.Input(key='ValorAtualizacao', size=(30, 1))]
]

crud_buttons = [
    [sg.Button('Criar Publicação', key='CRIAR_PUBLICACAO')],
    [sg.Button('Consultar Publicação', key='CONSULTAR_PUBLICACAO')],
    [sg.Button('Atualizar Publicação', key='ATUALIZAR_PUBLICACAO')],
    [sg.Button('Eliminar Publicação', key='ELIMINAR_PUBLICACAO')],
    [sg.Button('Listar Publicações', key='LISTAR_PUBLICACOES')],
    [sg.Button('Ordenar Publicações', key='ORDENAR_PUBLICACOES')]
]

# Layout do separador Análise
analise_layout = [
    [sg.Button('Distribuição de Publicações por Ano', key='ANALISE_ANO')],
    [sg.Button('Distribuição de Publicações por Mês', key='ANALISE_MES')],
    [sg.Button('Top 20 Autores Mais Produtivos', key='ANALISE_AUTORES')],
    [sg.Button('Distribuição de Publicações por Autor', key='ANALISE_POR_AUTOR')],
    [sg.Button('Top 20 Palavras-chave', key='ANALISE_PALAVRAS')],
    [sg.Button('Distribuição de Palavras-chave por Ano', key='ANALISE_PALAVRAS_ANO')]
]

# Layout principal com os separadores
tabs = [
    [sg.Tab('Importar/Exportar', importar_exportar_layout)],
    [sg.Tab('CRUD', [[sg.Column(crud_buttons), sg.VerticalSeparator(), sg.Column(crud_layout)]])],
    [sg.Tab('Análises', analise_layout)]
]

layout = [
    [sg.TabGroup(tabs)],
    [sg.Output(size=(100, 20), key='-OUTPUT-')]
]

# Escolha do tema: cores
sg.theme_background_color('Light Blue')
sg.theme_element_background_color('Light Blue')
sg.theme_element_text_color('black')
sg.theme_button_color(('white', 'Light Blue'))

# Janela principal
window = sg.Window(
    'Gestão de Publicações Científicas', 
    layout, 
    font=('Helvetica', 14), 
    size=(1000, 600), 
    element_justification='center',
    finalize=True
)
window.TKroot.geometry("+{}+{}".format(
    int((window.TKroot.winfo_screenwidth() - 1000) / 2),
    int((window.TKroot.winfo_screenheight() - 600) / 2)
))

# Event Listener
while True:
    event, values = window.read()

    if event == sg.WINDOW_CLOSED or event == 'SAIR':
        break

    elif event == 'CARREGAR_DATASET':
        novo_ficheiro = sg.popup_get_file('Selecionar novo dataset (CSV):')
        if novo_ficheiro:
            try:
                df = pd.read_csv(novo_ficheiro, low_memory=False)
                sg.popup("Dataset carregado com sucesso!")
            except Exception as e:
                sg.popup("Erro ao carregar o dataset:", str(e))

    elif event == 'CRIAR_PUBLICACAO':
        nova_publicacao = {
            'Key': values['ID'],
            'Item Type': values['Tipo'],
            'Publication Year': values['Ano'],
            'Author': values['Autor'],
            'Title': values['Titulo'],
            'Publication Title': values['TituloPublicacao'],
            'DOI': values['DOI'],
            'Url': values['URL'],
            'Abstract Note': values['Resumo'],
            'Manual Tags': values['Etiquetas'],
            'Date': values['Data']
        }
        df = criar_publicacao(df, nova_publicacao)

    elif event == 'CONSULTAR_PUBLICACAO':
        key = values['ID']
        resultado = consultar_publicacao(df, key)
        mostrar_resultado(resultado)

    elif event == 'ATUALIZAR_PUBLICACAO':
        key = values['ID']
        campo = values['CampoAtualizacao']
        valor = values['ValorAtualizacao']
        df = atualizar_publicacao(df, key, {campo: valor})

    elif event == 'ELIMINAR_PUBLICACAO':
        key = values['ID']
        df = eliminar_publicacao(df, key)

    elif event == 'LISTAR_PUBLICACOES':
        print(df.head())

    elif event == 'ORDENAR_PUBLICACOES':
        coluna = sg.popup_get_text('Ordenar por (Title/Publication Year):')
        asc = sg.popup_yes_no('Ordenar em ordem ascendente?') == 'Yes'
        df = ordenar_publicacoes(df, coluna, asc)
        print(df.head())

    elif event == 'GUARDAR_ALTERACOES':
        guardar_alteracoes(df)

    elif event == 'ANALISE_ANO':
        distribuicao_publicacoes_por_ano(df)

    elif event == 'ANALISE_MES':
        ano = int(sg.popup_get_text('Ano para análise:'))
        distribuicao_publicacoes_por_mes(df, ano)

    elif event == 'ANALISE_AUTORES':
        top_autores_mais_produtivos(df)

    elif event == 'ANALISE_POR_AUTOR':
        autor = sg.popup_get_text('Autor para análise:')
        if autor:  # Verifica se o autor foi informado
            try:
                distribuicao_publicacoes_por_autor(df, autor)
            except Exception as e:
                sg.popup("Erro na análise por autor:", str(e))
        else:
            sg.popup("Erro", "Por favor, insira um nome válido para o autor.")

    elif event == 'ANALISE_PALAVRAS':
        top_palavras_chave(df)

    elif event == 'ANALISE_PALAVRAS_ANO':
        distribuicao_palavras_chave_por_ano(df)

window.close()
