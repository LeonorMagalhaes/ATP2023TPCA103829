![transferir](C:\Users\Asus\Desktop\3ºANO\transferir.png)

<div style="text-align: center;">

# Algoritmos e Téncicas de Programação 

## Relatório do Projeto 

### Algoritmos e Técnicas de Programação 


#### Grupo 14
#### Leonor Magalhães (A103829)
#### Maria Cerqueira (A103907)



##### Licenciatura em Engenharia Biomédica 
##### Docentes: José Carlos Ramalho e Luís Filipe Cunha

Janeiro 2024

<div style="page-break-after: always;"></div>
</div>

### Conteúdo 

# Índice
- [Introdução](###Introdução)
- [Objetivos](#objetivos)
- [Menu](#metodologia)
  - [Menu Análise Estatística](#ferramentas-utilizadas)
- [Funções](#resultados)
  - [Menu Análise Estatística](#ferramentas-utilizadas)
- [Conclusão](#conclusao)

<div style="page-break-after: always;"></div>

### Introdução

O estudo apresentado descreve o desenvolvimento de um sistema em Python para a gestão de publicações científicas, com funcionalidades para criação, atualização, consulta e análise de métricas. 
São também apresentados gráficos que permitem ilustrar autores, temas e tendências ao longo do tempo, e os dados podem ser acedidos através de uma interface de linha de comandos (CLI) e uma interface gráfica. O projeto cumpre os requisitos especificados, incluindo armazenamento persistente e manipulação de dados.

<div style="page-break-after: always;"></div>

#### Menu 
De modo a facilitar o acesso a a cada uma das funcionalidades da aplicação, criamos um menu, que permite a seleção das diferentes opções de funcionalidade disponíveis de um modo intuitivo para o utilizador. 


![menu_layout](C:\Users\Asus\Desktop\Backup\Projeto Artigos Cientificos\src\prints_relatorio\def_menu.png)

![def_menu](C:\Users\Asus\Desktop\Backup\Projeto Artigos Cientificos\src\prints_relatorio\def_menu.png)

#### Menu da Análise de Publicações 
Para a análise gráfica de publicações, foi também elaborado um menu, de modo a fazer corresponder cada índice do menu, cada análise estatística.

#### Funções

As funções a seguir apresentadas, desenvolvidas no módulo CRUD, e, posteriormente, definidas de forma a serem conectadas à interface da aplicação, foram desenvolvidas tendo em vista o cumprimento de todas as funcionalidades que uma aplicaçaõ de gestão de aplicação de gestão de publicações científicas deve conter, sendo estas:


Funções do modelo CRUD:

1. Carregar Ficheiro:
Carrega um determinado dataset, que se é selecionado pelo utilizador, para a memória. 
![CarregaFicheiro](C:\Users\Asus\Desktop\3ºANO\ATP\projeto\prints_relatorio\CarregaFicheiro.png)

2. Cria Publicação:
Permite a criação de um novo artigo pelo utilizador, pedindo o título, resumo, as palavras-chave, DOI (Digital Object Identifier), a lista de autores que participaram na elaboração e a afiliação correspondente, url para o ficheiro PDF do artigo, data de publicação e url do artigo

![CriaPublicação](C:\Users\Asus\Desktop\3ºANO\ATP\projeto\prints_relatorio\CriaPublicação.png)

3. Consulta Publicação:
Permite pesquisar publicações, a partir um ou vários filtros diferentes (tanto podem ser título, como autores, afiliação, data de publicação e palavras-chave).
Esta função possibilita ainda ordenar as publicações encontradas pelos títulos e pela data de publicação, utilizando um formato de lista.

![ConsultaPublicação](C:\Users\Asus\Desktop\3ºANO\ATP\projeto\prints_relatorio\ConsultaPublicação.png)

4. Atualiza Publicações
Atualiza a informação de uma publicação, isto é, incluindo parâmetros como o seu título, data de publicação, resumo, palavras-chave, bem como os autores e as suas respetivas afiliações.

![AtualizaPublicacao](C:\Users\Asus\Desktop\3ºANO\ATP\projeto\prints_relatorio\AtualizaPublicacao.png)

5. Lista Autores: 
Lista os autores e acede aos artigos de cada autor da lista. Para além disto, esta função ordena os autores pela frequência de publicação de artigos e/ou por ordem alfabética.

![ListaAutores](C:\Users\Asus\Desktop\3ºANO\ATP\projeto\prints_relatorio\ListaAutores.png)

6. Elimina Publicação:
Elimina uma determinada publicação, dado um identificador 'DOI' do artigo associado à mesma.

## Funções e Definições da Interface 

Definição do dicionário 'entries':

O entries é um dicionário utilizado para guardar as referências aos campos de entrada de um formulário na interface gráfica. Através de um ciclo for, para cada par de rótulo e variável na lista fields, é criado um rótulo (Label) e um campo de entrada (Entry). O dicionário facilita o acesso aos valores inseridos pelos utilizadores, permitindo aceder a cada campo através da sua chave correspondente. Os campos são organizados numa grelha, com o rótulo na primeira coluna e o campo na segunda.

1. Função Criar Publicação Interface:

A função criar_publicacao_interface() recolhe os dados introduzidos pelo utilizador na interface gráfica e organiza-os num dicionário, adicionando-os, em seguida, ao Data Frame global, chamando a função criar_publicacao, já definida no módulo crud. 
Após esta adição, guarda as alterações no ficheiro CSV com a função guardar_alteracoes e atualiza o Data Frame na memória com o auxílio da função atualizar_dataframe.

![CriaPublicaçãoInter.png]()

2. Consultar Publicação Interface:
Permite procurar uma publicação específica no DataFrame global com base no identificador, key, fornecido pelo utilizador. Primeiro, atualiza o DataFrame em memória, utilizando a função atualizar_dataframe() para garantir que tem os dados mais recentes. Depois, obtém o identificador ‘key’  inserido pelo utilizador na interface gráfica e utiliza a função consultar_publicacao, já definida no módulo crud, para procurar a publicação correspondente no Data Frame. Por fim, o resultado desta pesquisa é exibido ao utilizador através da função mostrar_resultado().

![CriaPublicaçãoInter.png]()

3. Atualizar Publicação Interface:
Modifica certas informações de uma publicação existente no Data Frame, recolhendo os valores inseridos através interface gráfica. Primeiramente, identifica a publicação a ser atualizada através do identificador ‘key’ da publicação. Para além disto, atribui o novo valor aos campos desejados. Caso não queria alterar nenhum dos campos, basta que o utilizador pressione a tecla ‘Enter’, fazendo o programa continuar até ser alterado um novo campo. Em seguida, esta função chama a função atualizar_publicacao, já definida no módulo crud para aplicar a atualização ao Data Frame. Depois disso, guarda as alterações no ficheiro CSV com guardar_alteracoes e recarrega o DataFrame em memória com atualizar_dataframe. 

![CriaPublicaçãoInter.png]()

4. Eliminar Publicação Interface: 
Remove uma publicação do DataFrame, conhecida através do identificador ’key’ introduzido pelo utilizador. Esta função começa por verificar se a key introduzida existe no Data Frame. Se existir, utiliza a função eliminar_publicacao, inicialmente definida no módulo crud, para remover a publicação. Seguidamente, guarda as alterações no ficheiro CSV com guardar_alteracoes e recarrega o DataFrame em memória com atualizar_dataframe. 

![CriaPublicaçãoInter.png]()

## Interface Gráfica 
É de dada importância referir que, para a construção da interface gráfica do nosso trabalho, foi utilizada a interface gráfica 'Tkinter'. 
Decidimos que foi a escolha mais acertada após alguma pesquisa e aquisição de conhecimento noutras UC's, para além do facto de que esta biblioteca está inserida na instalação padrão do Python e não é necessária uma instalação separada da mesma.

Tal como para outros construtores de interface, como o PySimpleGUI, o Tkinter é possível criar janelas, botões, rótulos, caixas de texto, menus e muitos outros componentes de interface gráfica.

![CriaPublicaçãoInter.png]()

## Testes à aplicação
