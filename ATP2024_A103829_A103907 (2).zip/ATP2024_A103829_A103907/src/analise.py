import pandas as pd
import matplotlib.pyplot as plt

# Carregar o dataset tratado
FICHEIRO = r'C:/Users/Asus/Desktop/Backup/Projeto Artigos Cientificos/data/producao_cientifica_tratado.csv'
df = pd.read_csv(FICHEIRO)

# 1. DISTRIBUIÇÃO DE PUBLICAÇÕES POR ANO
def distribuicao_publicacoes_por_ano(df):
    """
    Gera um gráfico de barras com a distribuição de publicações por ano.
    """
    contagem_por_ano = df['Publication Year'].value_counts().sort_index()
    contagem_por_ano.plot(kind='bar', figsize=(12, 6))
    plt.title('Distribuição de Publicações por Ano')
    plt.xlabel('Ano')
    plt.ylabel('Número de Publicações')
    plt.show()

# 2. DISTRIBUIÇÃO DE PUBLICAÇÕES POR MÊS EM UM ANO ESPECÍFICO
def distribuicao_publicacoes_por_mes(df, ano):
    """
    Gera um gráfico de barras com a distribuição de publicações por mês em um ano específico.
    """
    # Garantir que as datas estão no formato correto
    df['Date'] = pd.to_datetime(df['Date'], format='%d-%m-%Y', errors='coerce')
    
    # Filtrar publicações pelo ano
    df_ano = df[(df['Publication Year'] == ano) & (df['Date'].notnull())].copy()
    
    if df_ano.empty:
        print(f"⚠️ Não há publicações disponíveis para o ano {ano} com datas válidas.")
        return
    
    # Extrair o mês
    df_ano['Month'] = df_ano['Date'].dt.month
    contagem_por_mes = df_ano['Month'].value_counts().sort_index()
    
    if contagem_por_mes.empty:
        print(f"⚠️ Não há dados suficientes para gerar o gráfico de publicações por mês no ano {ano}.")
        return
    
    contagem_por_mes.plot(kind='bar', figsize=(12, 6))
    plt.title(f'Distribuição de Publicações por Mês no Ano {ano}')
    plt.xlabel('Mês')
    plt.ylabel('Número de Publicações')
    plt.show()

# 3. TOP 20 AUTORES MAIS PRODUTIVOS
def top_autores_mais_produtivos(df):
    """
    Gera um gráfico de barras com os 20 autores mais produtivos.
    """
    autores = df['Author'].str.split(';').explode().str.strip()
    top_autores = autores.value_counts().head(20)
    top_autores.plot(kind='bar', figsize=(12, 6))
    plt.title('Top 20 Autores Mais Produtivos')
    plt.xlabel('Autor')
    plt.ylabel('Número de Publicações')
    plt.show()

# 4. DISTRIBUIÇÃO DE PUBLICAÇÕES DE UM AUTOR POR ANO
def distribuicao_publicacoes_por_autor(df, autor):
    """
    Gera um gráfico com a distribuição de publicações de um autor específico por ano.
    """
    df_autor = df[df['Author'].str.contains(autor, case=False, na=False)]
    contagem_por_ano = df_autor['Publication Year'].value_counts().sort_index()
    contagem_por_ano.plot(kind='bar', figsize=(12, 6))
    plt.title(f'Distribuição de Publicações por Ano - {autor}')
    plt.xlabel('Ano')
    plt.ylabel('Número de Publicações')
    plt.show()

# 5. TOP 20 PALAVRAS-CHAVE MAIS FREQUENTES
def top_palavras_chave(df):
    """
    Gera um gráfico com as 20 palavras-chave mais frequentes.
    """
    palavras = df['Manual Tags'].dropna().str.split(';').explode().str.strip()
    top_palavras = palavras.value_counts().head(20)
    top_palavras.plot(kind='bar', figsize=(12, 6))
    plt.title('Top 20 Palavras-chave Mais Frequentes')
    plt.xlabel('Palavra-chave')
    plt.ylabel('Frequência')
    plt.show()

# 6. DISTRIBUIÇÃO DE PALAVRAS-CHAVE POR ANO
def distribuicao_palavras_chave_por_ano(df):
    """
    Gera um gráfico com as palavras-chave mais frequentes ao longo dos anos.
    """
    palavras_ano = df[['Publication Year', 'Manual Tags']].dropna()
    palavras_ano['Manual Tags'] = palavras_ano['Manual Tags'].str.split(';')
    palavras_ano = palavras_ano.explode('Manual Tags')
    palavras_ano['Manual Tags'] = palavras_ano['Manual Tags'].str.strip()
    contagem = palavras_ano.groupby('Publication Year')['Manual Tags'].value_counts().unstack().fillna(0)
    contagem.head(10).plot(kind='bar', stacked=True, figsize=(12, 6))
    plt.title('Distribuição de Palavras-chave por Ano')
    plt.xlabel('Ano')
    plt.ylabel('Frequência')
    plt.show()

