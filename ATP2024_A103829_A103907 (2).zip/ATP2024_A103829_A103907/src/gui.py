import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import pandas as pd
from crud import *
from analise import *

# Caminho para o dataset tratado
FICHEIRO = r'C:\Users\Asus\Desktop\Backup\Projeto Artigos Cientificos\data\Producao_cientifica_tratado.csv'
df = pd.read_csv(FICHEIRO, low_memory=False)

# Função para atualizar o DataFrame global
def atualizar_dataframe():
    global df
    df = pd.read_csv(FICHEIRO, low_memory=False)

# Funções auxiliares para GUI
def mostrar_resultado(resultado):
    if resultado:
        messagebox.showinfo("Resultado", str(resultado))
    else:
        messagebox.showinfo("Resultado", "Nenhum resultado encontrado.")

# GUI Principal
def main():
    root = tk.Tk()
    root.title("Gestão de Publicações Científicas")
    root.geometry("1000x800")

    # Frame Principal
    frame_principal = ttk.Notebook(root)
    frame_crud = ttk.Frame(frame_principal)
    frame_analise = ttk.Frame(frame_principal)
    frame_import_export = ttk.Frame(frame_principal)

    frame_principal.add(frame_crud, text='CRUD')
    frame_principal.add(frame_analise, text='Análises')
    frame_principal.add(frame_import_export, text='Importar/Exportar')
    frame_principal.pack(expand=1, fill='both')

    # --- CRUD ---
    def criar_publicacao_interface():
        global df
        nova_publicacao = {
            'Key': entries['entry_key'].get(),
            'Item Type': entries['entry_item_type'].get(),
            'Publication Year': int(entries['entry_year'].get()),
            'Author': entries['entry_author'].get(),
            'Title': entries['entry_title'].get(),
            'Publication Title': entries['entry_pub_title'].get(),
            'DOI': entries['entry_doi'].get(),
            'Url': entries['entry_url'].get(),
            'Abstract Note': entries['entry_abstract'].get(),
            'Manual Tags': entries['entry_tags'].get(),
            'Date': entries['entry_date'].get()
        }
        df = criar_publicacao(df, nova_publicacao)
        guardar_alteracoes(df)
        atualizar_dataframe()
        messagebox.showinfo("Sucesso", "Publicação criada com sucesso!")

    def consultar_publicacao_interface():
        atualizar_dataframe()
        key = entries['entry_key'].get()
        resultado = consultar_publicacao(df, key)
        mostrar_resultado(resultado)

    def atualizar_publicacao_interface():
        key = entries['entry_key'].get()
        campo = entries['entry_campo'].get()
        valor = entries['entry_valor'].get()
        atualizar_publicacao(df, key, {campo: valor})
        guardar_alteracoes(df)
        atualizar_dataframe()
        messagebox.showinfo("Sucesso", "Publicação atualizada com sucesso!")

    def eliminar_publicacao_interface():
        global df
        key = entries['entry_key'].get()
        if key in df['Key'].values:
            df = eliminar_publicacao(df, key)
            guardar_alteracoes(df)
            atualizar_dataframe()
            messagebox.showinfo("Sucesso", "Publicação removida com sucesso!")
        else:
            messagebox.showwarning("Aviso", "Publicação não encontrada!")

    # Campos CRUD
    fields = [
        ('ID', 'entry_key'),
        ('Tipo', 'entry_item_type'),
        ('Ano', 'entry_year'),
        ('Autor', 'entry_author'),
        ('Título', 'entry_title'),
        ('Título da Publicação', 'entry_pub_title'),
        ('DOI', 'entry_doi'),
        ('URL', 'entry_url'),
        ('Resumo', 'entry_abstract'),
        ('Etiquetas', 'entry_tags'),
        ('Data (dd-mm-aaaa)', 'entry_date'),
        ('Campo para Atualização', 'entry_campo'),
        ('Valor para Atualização', 'entry_valor')
    ]

    entries = {}
    for i, (label, var) in enumerate(fields):
        ttk.Label(frame_crud, text=label + ':').grid(row=i, column=0)
        entries[var] = ttk.Entry(frame_crud)
        entries[var].grid(row=i, column=1)

    ttk.Button(frame_crud, text='Criar Publicação', command=criar_publicacao_interface).grid(row=14, column=0)
    ttk.Button(frame_crud, text='Consultar Publicação', command=consultar_publicacao_interface).grid(row=14, column=1)
    ttk.Button(frame_crud, text='Atualizar Publicação', command=atualizar_publicacao_interface).grid(row=15, column=0)
    ttk.Button(frame_crud, text='Eliminar Publicação', command=eliminar_publicacao_interface).grid(row=15, column=1)

    # --- Listar e Ordenar Publicações ---
    def listar_publicacoes_interface():
        janela_listar = tk.Toplevel()
        janela_listar.title("Lista de Publicações")
        janela_listar.geometry("800x600")
        
        text_area = tk.Text(janela_listar, wrap='none')
        text_area.pack(expand=True, fill='both')
        
        scrollbar_y = ttk.Scrollbar(janela_listar, orient='vertical', command=text_area.yview)
        scrollbar_y.pack(side='right', fill='y')
        text_area.config(yscrollcommand=scrollbar_y.set)
        
        scrollbar_x = ttk.Scrollbar(janela_listar, orient='horizontal', command=text_area.xview)
        scrollbar_x.pack(side='bottom', fill='x')
        text_area.config(xscrollcommand=scrollbar_x.set)
        
        # Remover coluna 'Abstract Note' e verificar se existe
        if 'Abstract Note' in df.columns:
            df_sem_resumo = df.drop(columns=['Abstract Note'])
        else:
            df_sem_resumo = df.copy()
        
        # Paginar os dados SEM a coluna 'Abstract Note'
        num_linhas = 50  # Número de linhas por página
        paginas = [df_sem_resumo.iloc[i:i+num_linhas] for i in range(0, len(df_sem_resumo), num_linhas)]
        pagina_atual = 0

        def carregar_pagina(pagina):
            text_area.config(state='normal')
            text_area.delete('1.0', tk.END)
            text_area.insert('1.0', paginas[pagina].to_string(index=False))
            text_area.config(state='disabled')
        
        def proxima_pagina():
            nonlocal pagina_atual
            if pagina_atual < len(paginas) - 1:
                pagina_atual += 1
                carregar_pagina(pagina_atual)
        
        def pagina_anterior():
            nonlocal pagina_atual
            if pagina_atual > 0:
                pagina_atual -= 1
                carregar_pagina(pagina_atual)
        
        carregar_pagina(pagina_atual)
        
        ttk.Button(janela_listar, text="Página Anterior", command=pagina_anterior).pack(side='left')
        ttk.Button(janela_listar, text="Próxima Página", command=proxima_pagina).pack(side='right')


    def ordenar_publicacoes_interface():
        coluna = simpledialog.askstring("Ordenar", "Digite o nome da coluna para ordenação:")
        if coluna in df.columns:
            df_ordenado = df.sort_values(by=coluna, ascending=True)
            
            # Exibir numa nova janela
            janela_ordenar = tk.Toplevel()
            janela_ordenar.title(f"Publicações Ordenadas por {coluna}")
            janela_ordenar.geometry("800x600")
            
            text_area = tk.Text(janela_ordenar, wrap='none')
            text_area.pack(expand=True, fill='both')
            
            scrollbar_y = ttk.Scrollbar(janela_ordenar, orient='vertical', command=text_area.yview)
            scrollbar_y.pack(side='right', fill='y')
            text_area.config(yscrollcommand=scrollbar_y.set)
            
            scrollbar_x = ttk.Scrollbar(janela_ordenar, orient='horizontal', command=text_area.xview)
            scrollbar_x.pack(side='bottom', fill='x')
            text_area.config(xscrollcommand=scrollbar_x.set)
            
            # Remover 'Abstract Note' se presente, para melhorar o desempenho
            if 'Abstract Note' in df_ordenado.columns:
                df_ordenado = df_ordenado.drop(columns=['Abstract Note'])
            
            # Exibir os dados ordenados
            text_area.insert('1.0', df_ordenado.to_string(index=False))
            text_area.config(state='disabled')
        else:
            messagebox.showerror("Erro", f"A coluna '{coluna}' não existe.")

    ttk.Button(frame_crud, text='Listar Publicações', command=listar_publicacoes_interface).grid(row=16, column=0)
    ttk.Button(frame_crud, text='Ordenar Publicações', command=ordenar_publicacoes_interface).grid(row=16, column=1)

    # --- Análises ---
    ttk.Label(frame_analise, text='Ano:').grid(row=0, column=0)
    entry_ano_analise = ttk.Entry(frame_analise)
    entry_ano_analise.grid(row=0, column=1)
    ttk.Label(frame_analise, text='Autor:').grid(row=1, column=0)
    entry_autor_analise = ttk.Entry(frame_analise)
    entry_autor_analise.grid(row=1, column=1)

    ttk.Button(frame_analise, text='Distribuição Anual', command=lambda: distribuicao_publicacoes_por_ano(df)).grid(row=2, column=0)
    ttk.Button(frame_analise, text='Distribuição Mensal', command=lambda: distribuicao_publicacoes_por_mes(df, int(entry_ano_analise.get()))).grid(row=2, column=1)
    ttk.Button(frame_analise, text='Top Autores', command=lambda: top_autores_mais_produtivos(df)).grid(row=3, column=0)
    ttk.Button(frame_analise, text='Distribuição por Autor', command=lambda: distribuicao_publicacoes_por_autor(df, entry_autor_analise.get())).grid(row=3, column=1)
    ttk.Button(frame_analise, text='Top Palavras-Chave', command=lambda: top_palavras_chave(df)).grid(row=4, column=0)
    ttk.Button(frame_analise, text='Distribuição Palavras por Ano', command=lambda: distribuicao_palavras_chave_por_ano(df)).grid(row=4, column=1)

    # --- Importação de CSV ---
    def importar_csv():
        global df
        ficheiro = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
        if ficheiro:
            try:
                df_novo = pd.read_csv(ficheiro, low_memory=False)
                df = pd.concat([df, df_novo], ignore_index=True)  # Adicionar dados importados ao DataFrame principal
                guardar_alteracoes(df)  # Guardar as alterações no CSV principal
                atualizar_dataframe()  # Garantir que o DataFrame global é atualizado
                messagebox.showinfo("Sucesso", "Dados importados com sucesso e guardados no CSV original!")
            except Exception as e:
                messagebox.showerror("Erro", f"Ocorreu um problema ao importar os dados: {e}")


    # --- Exportação com Filtros ---
    def exportar_csv_filtrado():
        filtro = simpledialog.askstring("Filtro", "Digite o filtro no formato Coluna=Valor")
        if filtro:
            coluna, valor = filtro.split('=')
            df_filtrado = df[df[coluna].str.contains(valor, case=False, na=False)]
            ficheiro = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
            if ficheiro:
                df_filtrado.to_csv(ficheiro, index=False)
                messagebox.showinfo("Sucesso", "Dados filtrados exportados com sucesso!")

    ttk.Label(frame_import_export, text="Importar/Exportar Dados CSV com Filtro", font=("Arial", 14)).pack(pady=10)
    ttk.Button(frame_import_export, text='Importar CSV', command=importar_csv).pack(pady=10)
    ttk.Button(frame_import_export, text='Exportar Dados Filtrados', command=exportar_csv_filtrado).pack(pady=10)

    root.mainloop()

if __name__ == '__main__':
    main()
